<template>
  <div class="card">
    <div class="card-header">Health</div>
    <div class="card-body">
      <blockquote class="blockquote mb-0">
        <p>
          After logging in, there is no user displayed in the upper right corner. Please refresh the
          page
        </p>
        <footer class="blockquote-footer">
          Helping every immigrant <cite title="Achieve health">Achieve health</cite>
        </footer>
      </blockquote>
    </div>
  </div>
</template>

<script setup></script>

<style scoped></style>

<!-- Code from bootstrap: https://getbootstrap.com/docs/5.3/components -->
