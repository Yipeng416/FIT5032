<template>
  <h1>Home View</h1>
</template>

<script setup></script>

<style scoped></style>
